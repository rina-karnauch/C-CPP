//
// Created by Rina Karnauch on 19/05/2020.
//

#include <stdio.h>
#include "RBTree.h"
#include <stdlib.h>

#ifdef TA_EX3_STRUCTS_H
#include "Structs.h"
#endif

#define START_SIZE 0
#define a 31
#define ba 321
#define bb 322
#define c 33
#define d 34
#define e 35


Node *newNode(void *data)
{
	Node *newN = NULL;
	newN = (Node *) malloc(sizeof(Node));

	if (newN == NULL)
	{
		free(newN);
		newN = NULL;
		return NULL;
	}

	newN->data = data;
	newN->color = RED;
	newN->parent = NULL;
	newN->left = NULL;
	newN->right = NULL;

	return newN;
}

Node *findPlace(RBTree *tree, void *data, CompareFunc compFunc)
/**
 * find the right place to insert in Binary Search Tree
 * @param root root of subtree
 * @param data data to be inserted
 * @param compFunc comparison functions
 * @return finds where the data should be in the tree
 */
{
	Node *current = tree->root;

	while (current != NULL)
	{
		int result = compFunc(data, current->data);
		if (result < 0)
		{
			if (current->left == NULL)
			{
				return current;
			}
			current = current->left;
		}
		else if (result > 0)
		{
			if (current->right == NULL)
			{
				return current;
			}
			current = current->right;
		}
		else if (result == 0)
		{
			return current;
		}
	}
	return NULL;
}

Node *findUncle(Node *current)
/**
 * a function to find the uncle
 * @param current: current son we talk about
 * @return a pointer to the uncle
 */
{

	Node *parent = current->parent;
	if (parent == NULL)
	{
		return NULL;
	}
	if (parent->left == current)
	{
		return parent->right;
	}
	if (parent->right == current)
	{
		return parent->left;
	}
	return NULL;
}

Node *insertToBST(RBTree *tree, CompareFunc compFunc, void *data)
/**
 * a function to put the node inside of the tree
 * @param tree: the tree root we insert inside
 * @param newN: the new Node to insert
 * @parem compFunc: the function we compare with
 * @return: the pointer to the new node place, NULL for failure.
 */
{
	Node *root = tree->root;
	if (root == NULL)
	{
		Node *n = newNode(data);
		if (n == NULL)
		{
			free(n);
			return NULL; // we have a problem
		}
		tree->root = n;
		return n;
	}

	Node *n = newNode(data);
	if (n == NULL)
	{
		free(n);
		return NULL;
	}

	Node *findParent = findPlace(tree, data, compFunc);

	if (compFunc(data, findParent->data) < 0)
	{
		findParent->left = n;
		n->parent = findParent;
	}
	else if (compFunc(data, findParent->data) > 0)
	{
		findParent->right = n;
		n->parent = findParent;
	}
	return n;
}

int case4Indentifior(Node *N)
{
	Node *P = N->parent;
	Node *G = P->parent;
	if (P->right == N && G->left == P)
	{
		return 1;
	}
	else if (P->left == N && G->right == P)
	{
		return 2;
	}
	else if (P->left == N && G->left == P)
	{
		return 3;
	}
	else if ((P->right == N && G->right == P))
	{
		return 4;
	}
	else
	{
		return 0;
	}
}

Color colorFinder(Node *n)
/**
 * a function to return the color of the node
 * @param n the node
 * @return the color
 */
{
	if (n == NULL)
	{
		return BLACK;
	}
	if (n->color == BLACK)
	{
		return BLACK;
	}
	if (n->color == RED)
	{
		return RED;
	}
	return BLACK;
}

void rightRotation(Node *y)
/**
 * function to do the right rotation
 * @param rotated : node to rotate
 */
{
	if (y == NULL)
	{
		return;
	}
	Node *xSubRight = NULL;
	Node *x = y->left;
	if (x != NULL)
	{
		xSubRight = x->right;
	}
	Node *yParent = y->parent;

	x->right = y;
	y->left = xSubRight;

	y->parent = x;
	if (xSubRight != NULL)
	{
		xSubRight->parent = y;
	}

	if (yParent != NULL)
	{
		if (yParent->right == y)
		{
			yParent->right = x;
			x->parent = yParent;
		}
		else if (yParent->left == y)
		{
			yParent->left = x;
			x->parent = yParent;
		}
	}
}

void leftRotation(Node *x)
/**
 * function to do the left roation
 * @param rotated: node to rotate
 */
{
	if (x == NULL)
	{
		return;
	}

	Node *ySubLeft = NULL;
	Node *y = x->right;

	if (y != NULL)
	{
		ySubLeft = y->left;
	}
	Node *xParent = x->parent;

	y->left = x;
	x->right = ySubLeft;

	x->parent = y;
	if (ySubLeft != NULL)
	{
		ySubLeft->parent = x;
	}

	if (xParent != NULL)
	{
		if (xParent->right == x)
		{
			xParent->right = y;
			y->parent = xParent;
		}
		else if (xParent->left == x)
		{
			xParent->left = y;
			y->parent = xParent;
		}
	}
}

int checkAndCorrect(Node *N, Node *root, RBTree *tree)
{
	if (root == N)
	{
		root->color = BLACK;
		return 1;
	}

	if (N->parent->color == BLACK)
	{
		return 1;
	}

	Node *P = N->parent;
	Node *U = findUncle(P);
	Node *G = P->parent;

	Color cP = colorFinder(P);
	Color cU = colorFinder(U);

	if (cP == RED && cU == RED)
	{
		// case 3
		P->color = BLACK;
		U->color = BLACK;
		if (G != NULL)
		{
			G->color = RED;
			checkAndCorrect(G, root, tree);
		}
		else
		{
			checkAndCorrect(P, root, tree);
		}
	}

	if (cP == RED && cU == BLACK)
	{
		// case 4
		switch (case4Indentifior(N))
		{
			case 0:
				// undescribed problem,
				return 0;
			case 1:
				// N is right son of left son
				leftRotation(P);
				// we receive a right linked list
				// now N is parent and P is child
				rightRotation(G);
				if (G == tree->root)
				{
					tree->root = N;
					N->parent = NULL;
				}
				N->color = BLACK;
				G->color = RED;
				break;
			case 2:
				// N is left son of right son
				rightRotation(P);
				// we receive a left linked list
				// now N is parent and P is child
				leftRotation(G);
				if (G == tree->root)
				{
					tree->root = N;
					N->parent = NULL;
				}
				N->color = BLACK;
				G->color = RED;
				break;
			case 3:
				// N is left son of left son
				rightRotation(G);
				if (G == root)
				{
					tree->root = P;
					P->parent = NULL;
				}
				// now N is Parent and P is child
				P->color = BLACK;
				G->color = RED;
				break;
			case 4:
				// N is right son of right son
				leftRotation(G);
				if (G == root)
				{
					tree->root = P;
					P->parent = NULL;
				}
				// now N is Parent and P is child
				P->color = BLACK;
				G->color = RED;
				break;
		}
	}
	return 1;
}


int insertToRBTree(RBTree *tree, void *data)
{
	if (data == NULL)
	{
		return 0;
	}
	if (tree == NULL)
	{
		return 0;
	}
	if (RBTreeContains(tree, data))
		/* we already have it in */
	{
		return 0;
	}
	else
		/* we need to insert */
	{
		CompareFunc compFunc = tree->compFunc;
		Node *n = insertToBST(tree, compFunc, data);

		Node *root = tree->root;

		if (n == NULL)
		{
			return 0;
		}

		tree->size = tree->size + 1;
		checkAndCorrect(n, root, tree);
	}

	return 1;

}

Node *brotherFinder(Node *current)
/**
 * a function to find the brother of the current Node
 * @param current: current
 * @return: the node
 */
{
	Node *p = current->parent;
	if (p == NULL)
	{
		return NULL;
	}
	if (p->right == current)
	{
		return p->left;
	}
	return p->right;
}


void swapColors(Node *nodeA, Node *nodeB)
/**
 * function to swap colors
 * @param nodeA first node
 * @param nodeB second node
 */
{
	Color cA = nodeA->color;
	Color cB = nodeB->color;

	nodeB->color = cA;
	nodeA->color = cB;

}

Node *leftMost(Node *current)
/**
 * a function to get the leftmost node from a subtree
 * @param current: current node
 * @return the leftmost node
 */
{
	while (current->left != NULL)
	{
		current = current->left;
	}
	return current;
}

Node *successorFinder(Node *from)
/**
 * function to find successor
 * @param from the successor of the from node
 * @return the node of comparison
 */
{
	/* easy case, we have right subtree */
	if (from->right != NULL)
	{
		return leftMost(from->right);
	}

	/* no right one to M? only on child, which is smaller, no successor. DB on the right*/

	return NULL;
}


void deleteLeafBST(Node **node)
/**
 * deleting from BST
 * @param root : the current root where we delete from
 * @param data the data we delete
 * @param compFunc: comparison fucntion
 * @return the new root of the tree
 */
{
	Node *parent = (*node)->parent;

	if (parent == NULL)
	{
		free((*node)->data);
		free(*node);
		*node = NULL;
	}
	else if (parent->right == (*node))
	{
		parent->right = NULL;
		(*node)->parent = NULL;
		free((*node)->data);
		free(*node);
		*node = NULL;
	}
	else if (parent->left == (*node))
	{
		parent->left = NULL;
		(*node)->parent = NULL;
		free((*node)->data);
		free(*node);
		*node = NULL;
	}
}

void swapMandS(Node *M, Node *S)
/**
 * a function to switch M and S if they exists
 * @param M: current node to delete.
 * @param S: left most child in the right subtree of M.
 */
{
	void *dataM = M->data;
	M->data = S->data;
	S->data = dataM;
}


Node *FarNode(Node *S, Node *P)
/**
 * a function to send back the far Node
 * @param S: the brother of deleted node
 * @param P: the parent of S and deleted
 * @return
 */
{
	if (P->right == S)
	{
		return S->right;
	}
	else
	{
		return S->left;
	}
}

Node *CloseNode(Node *S, Node *P)
/**
 * function to send back the closer Node
 * @param S: the brother of deleted node
 *  * @param P: the parent of S and deleted
 * @return: the farthest son of the brother
 */
{

	if (P->right == S)
	{
		return S->left;
	}
	else
	{
		return S->right;
	}

}

int SectionBChecker(Node *C, Node *P, Node *S, RBTree *tree)
/**
 * function to check what to do if M is black and C is Black according
 * to the orders that we got.
 * @param C: the son of deleted node.
 * @param P: the parent of deleted node.
 * @param S: the brother of deleted node.
 * @return number of sub option
 */
{
	if (C == tree->root)
	{
		return a;
	}
	Node *sRight = S->right;
	Node *sLeft = S->left;

	if (colorFinder(S) == BLACK && colorFinder(sRight) == BLACK && colorFinder(sLeft) == BLACK)
	{
		if (colorFinder(P) == RED)
		{
			return ba;
		}
		if (colorFinder(P) == BLACK)
		{
			return bb;
		}
	}
	else if (colorFinder(S) == RED)
	{
		return c;
	}
	else if (colorFinder(S) == BLACK)
	{
		if (colorFinder(FarNode(S, P)) == BLACK && colorFinder(CloseNode(S, P)) == RED)
		{
			return d;
		}
		if (colorFinder(FarNode(S, P)) == RED)
		{
			return e;
		}
	}
	return 0;
}

void recurHelper(Node *C, Node *P, Node *S, RBTree *tree)
/**
 * a function to recursivly fix the tree
 * @param C: son of deleted node
 * @param P: parent of deleted node
 * @param S: brother of deleted node
 * @param tree: the tree
 */
{

	switch (SectionBChecker(C, P, S, tree))
	{
		case a:
			/* C is now root, we can finish */
		{
			return;
		}

		case ba:
			/* P is red, C is black, and sright and sleft are black*/
		{
			P->color = BLACK;
			S->color = RED;
			return;
		}
		case bb:
			/* P is black, C is black, and sright and sleft are black*/
		{
			/*P->color = BLACK;
			S->color = RED;*/

			S->color = RED;
			C = P;
			S = brotherFinder(C);
			P = C->parent;


			//
			return recurHelper(C, P, S, tree);
			//
		}
		case c:
			/* S is red, C is black, and sright and sleft are black*/
		{
			S->color = BLACK;
			P->color = RED;
			if (P->right == S)
			{
				leftRotation(P);
				//
				S = P->right;
			}
			else
			{
				rightRotation(P);
				//
				S = P->left;
			}
			// c now is the son of P and p is the son of S.
			//
			return recurHelper(C, P, S, tree);
			//
		}
		case d:
			/* S is black, sFar is black and sClose is Red*/
		{
			//
			S->color = RED;
			Node *sC = CloseNode(S, P);
			sC->color = BLACK;
			if (P->right == S)
			{
				rightRotation(S);
				//
			}
			else
			{
				leftRotation(S);
			}
			return recurHelper(C, P, sC, tree);
		}
		case e:
			/* S is black, sFar is Red */
		{
			Node *sF = FarNode(S, P);
			swapColors(S, P);

			if (P->right == S)
			{
				leftRotation(P);
			}
			else
			{
				rightRotation(P);
			}

			sF->color = BLACK;
			return;
		}
	}
}

void handleBlack(Node *M, Node *C, Node *P, Node *S, RBTree *tree)
/**
 * a function to handle when M is black
 * @param M: black node, successor if got any ones, after swapping.
 * M got or 1 child or 0 childs.
 * @param C: the one possible child of M.
 * @param P: the parent of M.
 * @param S: the other son of P, brother of M.
 * @param tree: the tree.
 */
{

	if (colorFinder(C) == RED)
	{
		swapMandS(M, C);
		deleteLeafBST(&C);
		M->color = BLACK;
		return;
	}
	/* we got no children in C */
	if (tree->root == M)
	{
		tree->root = C;
	}

	deleteLeafBST(&M);

	if (tree->root == C)
	{
		return;
	}

	// c is always black

	recurHelper(C, P, S, tree);

}

Node *sonFinder(Node *current)
/**
 * a function to find current's only son
 * @param current: the node we look for its son
 * @return the son
 */
{
	if (current->left != NULL)
	{
		return current->left;
	}

	if (current->right != NULL)
	{
		return current->right;
	}
	else
	{
		return NULL;
	}
}


int deleteFromRBTree(RBTree *tree, void *data)
{
	if (tree == NULL)
	{
		return 0;
	}
	if ((tree->root) == NULL)
		/* we got nothing inside */
	{
		return 0;
	}

	CompareFunc compFunc = tree->compFunc;

	if (RBTreeContains(tree, data))
		/* if the value is in the tree we delete it */
	{

		Node *M = findPlace(tree, data, compFunc); // to delete
		tree->size = tree->size - 1;

		if (M->right != NULL && M->left != NULL)
			/* we got two children- we got successor
			 * we swap them */
		{
			Node *Successor = successorFinder(M);
			swapMandS(Successor, M);
			/* now we got M inside successor and successor inside M */
			M = Successor;
			Successor = NULL;
		}

		Node *P = M->parent;
		Node *C = sonFinder(M);
		Node *S = brotherFinder(M);

		switch (colorFinder(M))
		{
			case RED:
				deleteLeafBST(&M);
				C = NULL;
				S = NULL;
				return 1;
			case BLACK:
				handleBlack(M, C, P, S, tree);
		}

		return 1;
	}
	else
		/* if the value is not in the tree */
	{
		return 0;
	}

}


int RBTreeContains(const RBTree *tree, const void *data)
{
	if (tree == NULL)
	{
		// tree is empty
		return 0;
	}
	CompareFunc compFunc = tree->compFunc;
	Node *current = tree->root;
	while (current != NULL)
	{
		int result = compFunc(data, current->data);

		if (result < 0)
		{
			current = current->left;
		}

		else if (result > 0)
		{
			current = current->right;
		}

		else if (result == 0)
		{
			// we have found it!
			return 1;
		}
	}

	/*if we reaeched here, we haven't fount it */
	return 0;

}


int Inorder(Node *node, forEachFunc func, void *args, int *r)
/**
 * a function to do the function on the tree by inorder  traversal
 * @param node: the node we do it on
 * @param func: the function we apply
 */
{
	if (node == NULL)
	{
		return 1;
	}

	*r = *r + Inorder(node->left, func, args, r);

	*r = *r + func(node, args);
	if (!*r)
	{
		return 0;
	}
	*r = *r + Inorder(node->right, func, args, r);

	return *r;

}

int forEachRBTree(const RBTree *tree, forEachFunc func, void *args)
{
	if (tree == NULL)
	{
		return 0;
	}

	Node *node = tree->root;
	int r = 0;
	r = Inorder(node, func, args, &r);
	return r;
}

void freeNodes(Node **current)
/**
 * a function to free the current node we want to free
 * @param current: node we are freeing
 */
{
	if (current != NULL)
	{
		Node *left = (*current)->left;
		Node *right = (*current)->right;

		if (left != NULL)
		{
			freeNodes(&left);
		}
		if (right != NULL)
		{
			freeNodes(&right);
		}
		free((*current)->data);
		free(*current);
		*current = NULL;
	}

}

void freeRBTree(RBTree **tree)
{
	Node *current;
	current = (*tree)->root;
	if (current != NULL)
	{
		freeNodes(&current);
	}

	free(*tree);
	*tree = NULL;
}

RBTree *newRBTree(CompareFunc compFunc, FreeFunc freeFunc)
{
	RBTree *tree = NULL;

	/* the object of the tree */
	tree = (RBTree *) malloc(sizeof(RBTree));

	if (tree == NULL)
	{
		freeFunc(&tree);
		return NULL;
	}

	tree->size = START_SIZE;
	tree->compFunc = compFunc;
	tree->freeFunc = freeFunc;
	tree->root = NULL;

	return tree;

}
