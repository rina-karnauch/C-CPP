//
// Created by Rina Karnauch on 19/05/2020.
//

#include <string.h>
#include "Structs.h"


int min(int n1, int n2)
/**
 * a function to get minimum out of 2 numbers
 * @param n1
 * @param n2
 * @return the minimum out of them, or one of them if they are equal
 */
{
	if (n1 < n2)
	{
		return n1;
	}
	else
	{
		return n2;
	}

}

int vectorCompare1By1(const void *a, const void *b)
{
	Vector *A = (Vector *) (a);
	Vector *B = (Vector *) (b);

	int minimal = min(A->len, B->len);

	for (int i = 0; i < minimal; i++)
	{
		// we check all items till the "common place"
		if ((A->vector)[i] < (B->vector)[i])
		{
			return -1;
		}

		else if ((A->vector)[i] > (B->vector)[i])
		{
			return 1;
		}
	}

	// we have some items equal, now lets check lengths.

	if (A->len < B->len)
	{
		return -1;
	}
	else if (A->len > B->len)
	{
		return 1;
	}
	else
	{
		//if lengths are equal and we have arrived here it means all items are equal
		// means equality
		return 0;
	}

}

double normFinder(const double *v, const int len)
{
	if (v == NULL)
	{
		return 0;
	}
	double sum = 0;
	for (int i = 0; i < len; i++)
	{
		sum = sum + ((v[i]) * (v[i]));
	}
	return sum;
}

int copyIfNormIsLarger(const void *vector, void *maxVector)
{
	int v1Len = ((Vector *) vector)->len;
	double *vMax = ((Vector *) maxVector)->vector;
	double *vFirst = ((Vector *) vector)->vector;

	int result = vectorCompare1By1(vector, maxVector);

	if (result > 1 || maxVector == NULL)
	{
		vMax = realloc(vMax, v1Len * (sizeof(double)));
		if (vMax == NULL)
		{
			return 0;
		}
		for (int i = 0; i < v1Len; i++)
		{
			vMax[i] = vFirst[i];
		}

	}

	return 1;
}


Node *recurHelperS(Node *root, forEachFunc func, Node *ptr)
/**
 * a recursive helper function to apply func to each branch of the tree
 * to find the max norm
 * @param root: current root
 * @param func: function copyIfNormIsLarger
 * @param ptr: ptr to the current max
 * @return the ptr to the max.
 */
{
	if (!func(root->data, ptr))
	{
		return ptr;
	}

	Vector *current = root->data;

	func(current, ptr);

	recurHelperS(root->left, func, ptr);
	recurHelperS(root->right, func, ptr);

	return ptr;
}

Vector *findMaxNormVectorInTree(RBTree *tree)
{
	Node *ptr = tree->root;

	ptr = recurHelperS(tree->root, copyIfNormIsLarger, ptr);
	return ptr->data;

}

int maxNormOutOfTwo(const double a, const double b)
{
	if (a > b)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

void freeVector(void *vector)
{
	((Vector *) (vector))->len = 0;
	double *vA = ((Vector *) (vector))->vector;
	free(vA);
	vA = 0;
	vector = NULL;

}

void freeString(void *s)
{
	int len = (int) strlen((char *) s);
	for (int i = 0; i < len; i++)
	{
		free(&(s[i]));
	}
	free(s);
	s = NULL;
}

int concatenate(const void *word, void *pConcatenated)
{
	char *ptrString = (char *) pConcatenated;
	char *wordString = (char *) word;

	int toCopyLen = (int) strlen(wordString) - 1;
	int len = (int) strlen(pConcatenated);

	ptrString[len - 1] = '\n';

	for (int i = len - 2; i >= 0; i--)
	{
		ptrString[i] = wordString[toCopyLen];
		toCopyLen = toCopyLen - 1;
	}

	return 1;

}

int stringCompare(const void *a, const void *b)
{
	return strcmp(a, b);
}
